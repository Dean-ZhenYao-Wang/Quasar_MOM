This folder is for example XML files based on B2MML and/or BatchML
The examples are for different versions of B2MML and BatchML so check the version the file is based on before using it.
